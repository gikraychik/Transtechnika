﻿<?php
include_once("../../Php/view.php");
head("Зарядные устройства Skylla", $modes);
?>
<div id="text"><div>
	<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
	<td id="t1">
		<?php out_left_colomn(); ?>
	</td>
	<td id="t2">
		<h1>Зарядные устройства Skylla</h1><div id="cat_div">
<table cellpadding="0" cellspacing="1" width="100%">
<tr>
   <td id="cat_t1" rowspan="2">Модель</td>
   <td id="cat_t1" rowspan="2">Входное<BR> напряж.<BR> перем. тока</td>
   <td id="cat_t1" rowspan="2">Диапазон<BR> входного<BR> напр-я,<BR> перем. ток</td>
   <td id="cat_t1" rowspan="2">Диапазон<BR> входного<BR> напр-я,<BR> пост. тока, В</td>
   <td id="cat_t1" colspan="2">Зарядное напряжение<BR> пост. ток, В</td>
   <td id="cat_t1" rowspan="2">Ток<BR> зарядки<BR> серв.<BR> батареи,<BR> А</td>
   <td id="cat_t1" rowspan="2">Ток<BR> зарядки<BR> старт.<BR> батареи,<BR> А</td>
   <td id="cat_t1" rowspan="2">Емкость<BR> батарей,<BR> А/час.</td>
   <td id="cat_t1" rowspan="2">Габариты<BR>HxWxD, мм</td>
   <td id="cat_t1" rowspan="2">Масса,<BR> кг</td>
   <td id="cat_t1" rowspan="2">Цена,<BR> EUR</td>  
   <td id="cat_t1" rowspan="2">Цена,<BR> РУБ</td>
</tr>
<tr>
   <td id="cat_t1">"погло-<BR>щение"</td>
   <td id="cat_t1">"напол-<BR>нение"</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="stg24.30.php" title="Skylla-TG 24/30" class="cat">Skylla-TG 24/30</a></td>
<td id="cat_t2">230</td>
<td id="cat_t2">185-264 В 45-65 Гц</td>
<td id="cat_t2">180-400</td>
<td id="cat_t2">28.5</td>
<td id="cat_t2">26.5</td>
<td id="cat_t2">30.0</td>
<td id="cat_t2">4.0</td>
<td id="cat_t2">150-500</td>
<td id="cat_t2">365x 250x 147</td>
<td id="cat_t2">5,0</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="stg24.30GL.php" title="Skylla-TG 24/30 / GL" class="cat">Skylla-TG 24/30 / GL</a></td>
<td id="cat_t3">230</td>
<td id="cat_t3">90-265 В</td>
<td id="cat_t3">90-400</td>
<td id="cat_t3">28.5</td>
<td id="cat_t3">26.5</td>
<td id="cat_t3">30.0</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">150-300</td>
<td id="cat_t3">365x 250x 147</td>
<td id="cat_t3">5,0</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="stg24.30GMDSS.php" title="Skylla-TG 24/30 / GMDSS" class="cat">Skylla-TG 24/30 / GMDSS</a></td>
<td id="cat_t2">110, 230</td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">----</td>
<td id="cat_t2">28.5</td>
<td id="cat_t2">26.5</td>
<td id="cat_t2">30.0</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">365x 250x 147</td>
<td id="cat_t2">6.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="stg24.50.php" title="Skylla-TG 24/50 " class="cat">Skylla-TG 24/50 </a></td>
<td id="cat_t3">230</td>
<td id="cat_t3">185-264 В 45-65 Гц</td>
<td id="cat_t3">180-400</td>
<td id="cat_t3">28.5</td>
<td id="cat_t3">26.5</td>
<td id="cat_t3">50,0</td>
<td id="cat_t3">4.0</td>
<td id="cat_t3">150-500</td>
<td id="cat_t3">365x 250x 147</td>
<td id="cat_t3">5,0</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="stg24.503ph.php" title="Skylla-TG 24/50  3-фазы " class="cat">Skylla-TG 24/50  3-фазы </a></td>
<td id="cat_t2">3 x 400</td>
<td id="cat_t2">185-264 В 45-65 Гц</td>
<td id="cat_t2">----</td>
<td id="cat_t2">28.5</td>
<td id="cat_t2">26.5</td>
<td id="cat_t2">50,0</td>
<td id="cat_t2">4.0</td>
<td id="cat_t2">250-500</td>
<td id="cat_t2">365x 250x 257</td>
<td id="cat_t2">13,00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="stg24.50GL.php" title="Skylla-TG 24/50 / GL" class="cat">Skylla-TG 24/50 / GL</a></td>
<td id="cat_t3">230</td>
<td id="cat_t3">90-265 В</td>
<td id="cat_t3">90-400</td>
<td id="cat_t3">28.5</td>
<td id="cat_t3">26.5</td>
<td id="cat_t3">50,0</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">250-500</td>
<td id="cat_t3">365x 250x 147</td>
<td id="cat_t3">5,0</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="stg24.50GMDSS.php" title="Skylla-TG 24/50 / GMDSS" class="cat">Skylla-TG 24/50 / GMDSS</a></td>
<td id="cat_t2">110, 230</td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">----</td>
<td id="cat_t2">28.5</td>
<td id="cat_t2">26.5</td>
<td id="cat_t2">50,0</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">365x 250x 147</td>
<td id="cat_t2">6.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="stg24.80.php" title="Skylla-TG 24/80 " class="cat">Skylla-TG 24/80 </a></td>
<td id="cat_t3">230</td>
<td id="cat_t3">185-264 В 45-65 Гц</td>
<td id="cat_t3">180-400</td>
<td id="cat_t3">28.5</td>
<td id="cat_t3">26.5</td>
<td id="cat_t3">75,0</td>
<td id="cat_t3">4.0</td>
<td id="cat_t3">400-800</td>
<td id="cat_t3">365x 250x 257</td>
<td id="cat_t3">10,00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="stg24.80GL.php" title="Skylla-TG 24/80 GL" class="cat">Skylla-TG 24/80 GL</a></td>
<td id="cat_t2">230</td>
<td id="cat_t2">90-265 В</td>
<td id="cat_t2">90-400</td>
<td id="cat_t2">28.5</td>
<td id="cat_t2">26.5</td>
<td id="cat_t2">80.0</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">400-800</td>
<td id="cat_t2">365x 250x 257</td>
<td id="cat_t2">10,00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="stg24.100.php" title="Skylla-TG 24/100" class="cat">Skylla-TG 24/100</a></td>
<td id="cat_t3">230</td>
<td id="cat_t3">185-264 В 45-65 Гц</td>
<td id="cat_t3">180-400</td>
<td id="cat_t3">28.5</td>
<td id="cat_t3">26.5</td>
<td id="cat_t3">100.0</td>
<td id="cat_t3">4.0</td>
<td id="cat_t3">500-1000</td>
<td id="cat_t3">365x 250x 257</td>
<td id="cat_t3">10,00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="stg24.1003ph.php" title="Skylla-TG 24/100 3-фазы " class="cat">Skylla-TG 24/100 3-фазы </a></td>
<td id="cat_t2">3 x 400 	</td>
<td id="cat_t2">320-450 В 45-65 Гц</td>
<td id="cat_t2">----</td>
<td id="cat_t2">28.5</td>
<td id="cat_t2">26.5</td>
<td id="cat_t2">100.0</td>
<td id="cat_t2">4.0</td>
<td id="cat_t2">500-1000</td>
<td id="cat_t2">515x 260x 265</td>
<td id="cat_t2">23.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="stg24.100GGL.php" title="Skylla-TG 24/100-G GL " class="cat">Skylla-TG 24/100-G GL </a></td>
<td id="cat_t3">230</td>
<td id="cat_t3">90-265 В</td>
<td id="cat_t3">90-400</td>
<td id="cat_t3">28.5</td>
<td id="cat_t3">26.5</td>
<td id="cat_t3">100,0</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">500-1000</td>
<td id="cat_t3">365x 250x 257</td>
<td id="cat_t3">10,00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="stg48.25.php" title="Skylla-TG 48/25 " class="cat">Skylla-TG 48/25 </a></td>
<td id="cat_t2">230</td>
<td id="cat_t2">185-264 В 45-65 Гц</td>
<td id="cat_t2">180-400</td>
<td id="cat_t2">57.0</td>
<td id="cat_t2">53,0</td>
<td id="cat_t2">25,0</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">125-250</td>
<td id="cat_t2">365x 250x 147</td>
<td id="cat_t2">5,50</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="stg48.50.php" title="Skylla-TG 48/50 " class="cat">Skylla-TG 48/50 </a></td>
<td id="cat_t3">230</td>
<td id="cat_t3">185-264 В 45-65 Гц</td>
<td id="cat_t3">180-400</td>
<td id="cat_t3">57.0</td>
<td id="cat_t3">53,0</td>
<td id="cat_t3">50,0</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">250-500</td>
<td id="cat_t3">365x 250x 257</td>
<td id="cat_t3">10,00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr></table></div>

	</td>
	</tr></table>
</div>

<?php tail($modes); ?>