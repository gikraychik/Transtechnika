﻿<?php
include_once("../../Php/view.php");
head("Дополнительное оборудование", $modes);
?>
<div id="text"><div>
	<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
	<td id="t1">
		<?php out_left_colomn(); ?>
	</td>
	<td id="t2">
		<h1>Дополнительное оборудование</h1>
<div id="cat_div">
<table cellpadding="0" cellspacing="1" width="100%">
<tr>
   <td id="cat_t1" TITLE="Модель">Модель</td>
<td id="cat_t1" TITLE="Габариты HeightxWidtdxDeptd, мм">Габариты<BR>HxWxD, мм</td>
<td id="cat_t1" TITLE="Масса, кг">Масса,<BR> кг</td>
<td id="cat_t1" TITLE="Цена, EUR">Цена,<BR> EUR</td>
<td id="cat_t1" TITLE="Цена, РУБ">Цена,<BR> РУБ</td>
</tr><tr><td colspan="5" id="cat_t1" class="cat_price" style="text-align:left;">РАСПРЕДЕЛЕНИЕ ПОСТ. ТОКА</td></tr><tr>
<td id="cat_t3" style="text-align:left;">Соединительная коробка ESP пост. тока, в пластмассовом корпусе: соед. пульта ESP / соед. устр-ва контроля батареи / соед. вольтметра / 4 предохр. типа Mega</td>
<td id="cat_t3">130x 395x 315</td>
<td id="cat_t3">3.10</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Монтажная плата пост. тока, 5 предохр. типа ATO / 4 предохр. типа Mega</td>
<td id="cat_t2">280x 340x 120</td>
<td id="cat_t2">3.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Соединительная коробка пост. тока, в стальном корпусе: 5 предохр. типа ATO / 4 предохр. типа Mega</td>
<td id="cat_t3">300x 380x 210</td>
<td id="cat_t3">5.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr><td colspan="5" id="cat_t1" class="cat_price" style="text-align:left;">VE.NET</td></tr><tr>
<td id="cat_t2" style="text-align:left;">VE.Net Панель (VPN)</td>
<td id="cat_t2">65x 120x 40</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">VE.Net Панель GMDSS</td>
<td id="cat_t3">65x 120x 40</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">VE.Net Панель Blue Power (BPP)</td>
<td id="cat_t2">130x 120x 40</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">VE.Net Контроллер батареи (VBC) 12-24 В, включая шунт 500A и присоед. к-т</td>
<td id="cat_t3">105x 75x 22</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">VE.Net Контроллер батареи (VBC) 48 В, включая шунт 500A и присоед. к-т</td>
<td id="cat_t2">105x 75x 22</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">VE.Net Соединительный модуль</td>
<td id="cat_t3">70x 170x 250</td>
<td id="cat_t3">0.75</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">VE.Net Преобразователь в VE 9бит RS485</td>
<td id="cat_t2">30x 105x 72</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">VE.Net Контроллер генератора</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">VE.Net Tank Monitor (ток)</td>
<td id="cat_t2">105x 75x 22</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">VE.Net Tank Monitor (сопротивление)</td>
<td id="cat_t3">105x 75x 22</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">VE.Net Tank Monitor (напряжение)</td>
<td id="cat_t2">105x 75x 22</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr><td colspan="5" id="cat_t1" class="cat_price" style="text-align:left;">ДИСТАНЦИОННЫЕ ПАНЕЛИ</td></tr><tr>
<td id="cat_t3" style="text-align:left;">Панель VE.Bus Multi 16/200A</td>
<td id="cat_t3">65x 120x 40</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Панель VE.Bus Multi 30/200A</td>
<td id="cat_t2">65x 120x 40</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Цифровая панель Multi 200/200A</td>
<td id="cat_t3">65x 120x 40</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Панель Phoenix PowerMan, 16А или 30А</td>
<td id="cat_t2">65x 120x 40</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Панель инвертора Phoenix</td>
<td id="cat_t3">65x 60x 40</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Панель зарядного устр. Phoenix</td>
<td id="cat_t2">65x 120x 40</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Розетка переменного тока, "мама"</td>
<td id="cat_t3">65x 60x 40</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Панель переключения зарядки</td>
<td id="cat_t2">65x 60x 40</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Панель Skylla</td>
<td id="cat_t3">65x 60x 40</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Панель сигнализации батареи</td>
<td id="cat_t2">65x 120x 40</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Панель инвертора Phoenix 750 ВА, включая кабель 3 м</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr><td colspan="5" id="cat_t1" class="cat_price" style="text-align:left;">ПАНЕЛИ СИСТЕМЫ ESP</td></tr><tr>
<td id="cat_t2" style="text-align:left;">ESP Панель мониторинга системы, включая Multi Plus, 16А или 30А</td>
<td id="cat_t2">260x 160</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">ESP Панель с 4 автоматами защиты сети, перем. или пост. тока (1x 20А, 1x 16А, 1x 10А, 1x 5А)</td>
<td id="cat_t3">130x 160</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">ESP Панель с 11 автоматами защиты сети, перем. или пост. тока (1x 20А, 2x 16А, 5x 10А, 3x 5А)</td>
<td id="cat_t2">260x 160</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">ESP Глухая панель</td>
<td id="cat_t3">130x 160</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">ESP VE.Net панель Blue Power</td>
<td id="cat_t2">130x 160</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">ESP VE.Net панель</td>
<td id="cat_t3">130x 160</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">ESP Многофункциональная панель управления</td>
<td id="cat_t2">130x 160</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">ESP AC Sensor Box</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr><td colspan="5" id="cat_t1" class="cat_price" style="text-align:left;">КАБЕЛИ БЕРЕГОВОГО ПИТАНИЯ</td></tr><tr>
<td id="cat_t2" style="text-align:left;">Кабель берегового питания 25 м 10А</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Кабель берегового питания 15 м 16А</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Кабель берегового питания 25 м 16А</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Кабель берегового питания 15 м 32А</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Кабель берегового питания 25 м 32А</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Розетка бортовая, "папа", 16 А, из нерж. стали, с крышкой</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Розетка бортовая, "папа", 32 А, из нерж. стали, с крышкой</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Разъем для бортовой розетки 16 А, 16A/250В пер. тока (2p/3w)</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Разъем для бортовой розетки 32 А, 32A/250В пер. тока (2p/3w)</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr><td colspan="5" id="cat_t1" class="cat_price" style="text-align:left;">УСТРОЙСТВО КОНТРОЛЯ АККУМУЛЯТОРА</td></tr><tr>
<td id="cat_t3" style="text-align:left;">Монитор батареи BMV 600 прецизионный, 9-90 В пост. тока, с шунтом 500 А и соединит. комплектом</td>
<td id="cat_t3">65x 65x 30</td>
<td id="cat_t3">0.30</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Монитор батареи BMV 602 прецизионный, 9-90 В пост. тока, с шунтом 500 А и соединит. комплектом</td>
<td id="cat_t2">65x 65x 30</td>
<td id="cat_t2">0.30</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Монитор батареи BMV 602H прецизионный, 60-160 В пост. тока, с шунтом 500 А и соединит. комплектом (подходит только для систем с отрицательным заземлением)</td>
<td id="cat_t3">65x 65x 30</td>
<td id="cat_t3">3.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Кабель данных RS232 для BMV 602, с программным обеспечением</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr><td colspan="5" id="cat_t1" class="cat_price" style="text-align:left;">АККУМУЛЯТОРНЫЕ РАЗЪЕДИНИТЕЛИ</td></tr><tr>
<td id="cat_t3" style="text-align:left;">Cyrix 80/24</td>
<td id="cat_t3">46x 46x 80</td>
<td id="cat_t3">0.11</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Cyrix 400/12</td>
<td id="cat_t2">78x 102x 110</td>
<td id="cat_t2">0.90</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Cyrix-i 12/24В-100А, интеллектуальный сумматор</td>
<td id="cat_t3">46x 46x 80</td>
<td id="cat_t3">0.11</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Cyrix-i 12/24В-200А, интеллектуальный сумматор</td>
<td id="cat_t2">78x 102x 110</td>
<td id="cat_t2">0.90  	</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Cyrix-i 12/24В-400А, интеллектуальный сумматор</td>
<td id="cat_t3">78x 102x 110</td>
<td id="cat_t3">0.90  	</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Cyrix-i 24/48В-400А, интеллектуальный сумматор</td>
<td id="cat_t2">78x 102x 110</td>
<td id="cat_t2">0.90  	</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr><td colspan="5" id="cat_t1" class="cat_price" style="text-align:left;">ГЕНЕРАТОРЫ</td></tr><tr>
<td id="cat_t3" style="text-align:left;">Генератор 60-150-SR-IG 12В/150А</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Генератор 60-24-70-SR-IG 24В/70А </td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Генератор 94-210-12-IG 12В/210А, с многоступенчатым регулятором MC-612-H 12В-Max и 2 темп. датчика</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Генератор 94-140-24-IG 24В/140А, с многоступенчатым регулятором MC-624-H 24В-Max и 2 темп. датчика</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr></table></div>

	</td>
	</tr></table>
</div>

<?php tail($modes); ?>