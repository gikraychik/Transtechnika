﻿<?php
include_once("../../Php/view.php");
head("Зарядные устройства Centaur", $modes);
?>
<div id="text"><div>
	<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
	<td id="t1">
		<?php out_left_colomn(); ?>
	</td>
	<td id="t2">
		<h1>Зарядные устройства Centaur</h1><div id="cat_div">
<table cellpadding="0" cellspacing="1" width="100%">
<tr>
   <td id="cat_t1" rowspan="2">Модель</td>
   <td id="cat_t1" rowspan="2">Диапазон<BR> входного<BR> напряжения,<BR> перем. ток</td>
   <td id="cat_t1" colspan="2">Зарядное напряжение<BR> пост. ток, В</td>
   <td id="cat_t1" rowspan="2">Кол-во<BR> батарей<BR> на<BR> выходе</td>
   <td id="cat_t1" rowspan="2">Ток<BR> зарядки,<BR> А</td>
   <td id="cat_t1" rowspan="2">Реком.<BR> емкость<BR> батарей,<BR> А/час.</td>
   <td id="cat_t1" rowspan="2">Габариты<BR>HxWxD, мм</td>
   <td id="cat_t1" rowspan="2">Масса,<BR> кг</td>
   <td id="cat_t1" rowspan="2">Цена,<BR> EUR</td>
   <td id="cat_t1" rowspan="2">Цена,<BR> РУБ</td>
</tr>
<TR>
	<td id="cat_t1">"погло-<BR>щение"</td>
	<td id="cat_t1">"напол-<BR>нение"</td>
</TR><tr>
<td id="cat_t2" style="text-align:left;"><a href="c12.20.php" title="Centaur 12/20 " class="cat">Centaur 12/20 </a></td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">14.3</td>
<td id="cat_t2">13.5</td>
<td id="cat_t2">3</td>
<td id="cat_t2">20.0</td>
<td id="cat_t2">80-200</td>
<td id="cat_t2">355x 215x 110</td>
<td id="cat_t2">3.80</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="c12.30.php" title="Centaur 12/30 " class="cat">Centaur 12/30 </a></td>
<td id="cat_t3">90-265 В 45-65 Гц</td>
<td id="cat_t3">14.3</td>
<td id="cat_t3">13.5</td>
<td id="cat_t3">3</td>
<td id="cat_t3">30.0</td>
<td id="cat_t3">120-300</td>
<td id="cat_t3">355x 215x 110</td>
<td id="cat_t3">3.80</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="c12.40.php" title="Centaur 12/40 " class="cat">Centaur 12/40 </a></td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">14.3</td>
<td id="cat_t2">13.5</td>
<td id="cat_t2">3</td>
<td id="cat_t2">40.0</td>
<td id="cat_t2">160-400</td>
<td id="cat_t2">426x 239x 135</td>
<td id="cat_t2">5.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="c12.50.php" title="Centaur 12/50  " class="cat">Centaur 12/50  </a></td>
<td id="cat_t3">90-265 В 45-65 Гц</td>
<td id="cat_t3">14.3</td>
<td id="cat_t3">13.5</td>
<td id="cat_t3">3</td>
<td id="cat_t3">50.0</td>
<td id="cat_t3">200-500</td>
<td id="cat_t3">426x 239x 135</td>
<td id="cat_t3">5.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="c12.60.php" title="Centaur 12/60 " class="cat">Centaur 12/60 </a></td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">14.3</td>
<td id="cat_t2">13.5</td>
<td id="cat_t2">3</td>
<td id="cat_t2">60.0</td>
<td id="cat_t2">240-600</td>
<td id="cat_t2">426x 239x 135</td>
<td id="cat_t2">5.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="c12.80.php" title="Centaur 12/80 " class="cat">Centaur 12/80 </a></td>
<td id="cat_t3">90-265 В 45-65 Гц</td>
<td id="cat_t3">14.3</td>
<td id="cat_t3">13.5</td>
<td id="cat_t3">3</td>
<td id="cat_t3">80.0</td>
<td id="cat_t3">320-800</td>
<td id="cat_t3">505x 255x 130</td>
<td id="cat_t3">12.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="c12.100.php" title="Centaur 12/100" class="cat">Centaur 12/100</a></td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">14.3</td>
<td id="cat_t2">13.5</td>
<td id="cat_t2">3</td>
<td id="cat_t2">100.0</td>
<td id="cat_t2">400-1000</td>
<td id="cat_t2">505x 255x 130</td>
<td id="cat_t2">12.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="c24.16.php" title="Centaur 24/16 " class="cat">Centaur 24/16 </a></td>
<td id="cat_t3">90-265 В 45-65 Гц</td>
<td id="cat_t3">28.5</td>
<td id="cat_t3">27.0</td>
<td id="cat_t3">3</td>
<td id="cat_t3">16.0</td>
<td id="cat_t3">45-150</td>
<td id="cat_t3">355x 215x 110</td>
<td id="cat_t3">3.80</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="c24.30.php" title="Centaur 24/30" class="cat">Centaur 24/30</a></td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">28.5</td>
<td id="cat_t2">27.0</td>
<td id="cat_t2">3</td>
<td id="cat_t2">30.0</td>
<td id="cat_t2">120-300</td>
<td id="cat_t2">426x 239x 135</td>
<td id="cat_t2">5.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="c24.40.php" title="Centaur 24/40 " class="cat">Centaur 24/40 </a></td>
<td id="cat_t3">90-265 В 45-65 Гц</td>
<td id="cat_t3">28.5</td>
<td id="cat_t3">27.0</td>
<td id="cat_t3">3</td>
<td id="cat_t3">40.0</td>
<td id="cat_t3">160-400</td>
<td id="cat_t3">505x 255x 130</td>
<td id="cat_t3">12.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="c24.60.php" title="Centaur 24/60 " class="cat">Centaur 24/60 </a></td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">28.5</td>
<td id="cat_t2">27.0</td>
<td id="cat_t2">3</td>
<td id="cat_t2">60.0</td>
<td id="cat_t2">240-600</td>
<td id="cat_t2">505x 255x 130</td>
<td id="cat_t2">12.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="c24.80.php" title="Centaur 24/80 " class="cat">Centaur 24/80 </a></td>
<td id="cat_t3">90-265 В 45-65 Гц</td>
<td id="cat_t3">28.5</td>
<td id="cat_t3">27.0</td>
<td id="cat_t3">3</td>
<td id="cat_t3">80.0</td>
<td id="cat_t3">320-800</td>
<td id="cat_t3">505x 255x 130</td>
<td id="cat_t3">16.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="c24.100.php" title="Centaur 24/100 " class="cat">Centaur 24/100 </a></td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">28.5</td>
<td id="cat_t2">27.0</td>
<td id="cat_t2">3</td>
<td id="cat_t2">100.0</td>
<td id="cat_t2">400-1000</td>
<td id="cat_t2">505x 255x 130</td>
<td id="cat_t2">16.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="c12.200.php" title="Centaur 12/200" class="cat">Centaur 12/200</a></td>
<td id="cat_t3">90-265 В 45-65 Гц</td>
<td id="cat_t3">14.3</td>
<td id="cat_t3">13.5</td>
<td id="cat_t3">3</td>
<td id="cat_t3">200.0</td>
<td id="cat_t3">800-2000</td>
<td id="cat_t3">505x 255x 130</td>
<td id="cat_t3">18.50</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr></table></div>

	</td>
	</tr></table>
</div>

<?php tail($modes); ?>