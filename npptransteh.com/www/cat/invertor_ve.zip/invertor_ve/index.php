﻿<?php
include_once("../../Php/view.php");
head("Инверторы Victron Energy");
?>
   <div id="text"><div>
      <table cellpadding="0" cellspacing="0" width="100%"><tr>
	  <td id="t1">
	  <?php out_left_colomn(); ?>
	  </td>
	  <td id="t2">
<h1>Инверторы Victron Energy</h1><table cellpadding="0" cellspacing="1" width="100%">
<tr>
   <td id="cat_t1">Модель</td>
   <td id="cat_t1">Диапазон<BR> входн.<BR> напряж.<BR> пост.<BR> тока, В</td>
   <td id="cat_t1">Выходн.<BR> напря-<BR>жение</td>
   <td id="cat_t1">Постоян.<BR> выходн.<BR> мощность<BR> при 25°C,<BR> ВА</td>
   <td id="cat_t1">Пиковая<BR> мощн.,<BR> Вт</td>
   <td id="cat_t1">Габариты<BR>HxWxD, мм</td>
   <td id="cat_t1">Масса,<BR> кг</td>
   <td id="cat_t1">Цена,<BR> EUR</td>
   <td id="cat_t1">Цена,<BR> РУБ</td>
</tr>
<tr>
<td id="cat_t3" style="text-align:left;"><a href="ph12.180.php" title="Phoenix 12/180 " class="cat">Phoenix 12/180 </a></td>
<td id="cat_t3">10,5-15,5</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">180</td>
<td id="cat_t3">200</td>
<td id="cat_t3">72x 132x 200</td>
<td id="cat_t3">2.70</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="ph12.350.php" title="Phoenix 12/350" class="cat">Phoenix 12/350</a></td>
<td id="cat_t2">10,5-15,5</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">350</td>
<td id="cat_t2">500</td>
<td id="cat_t2">72x 155x 237</td>
<td id="cat_t2">3.50</td>
<td id="cat_t2" class="cat_price">--	</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="ph12.750.php" title="Phoenix 12/750 " class="cat">Phoenix 12/750 </a></td>
<td id="cat_t3">10,5-15,5</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">750</td>
<td id="cat_t3">1400</td>
<td id="cat_t3">72x 180x 295</td>
<td id="cat_t3">2.70</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phc12.1200.php" title="Phoenix C 12/1200" class="cat">Phoenix C 12/1200</a></td>
<td id="cat_t2">9,5-16,0</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">1200</td>
<td id="cat_t2">2200</td>
<td id="cat_t2">375x 214x 110</td>
<td id="cat_t2">10.00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phc12.1600.php" title="Phoenix C 12/1600" class="cat">Phoenix C 12/1600</a></td>
<td id="cat_t3">9,5-16,0</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">1600</td>
<td id="cat_t3">2300</td>
<td id="cat_t3">375x 214x 110</td>
<td id="cat_t3">10,00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phc12.2000.php" title="Phoenix C 12/2000 " class="cat">Phoenix C 12/2000 </a></td>
<td id="cat_t2">9,5-16,0</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">2000</td>
<td id="cat_t2">4000</td>
<td id="cat_t2">520x 255x 125</td>
<td id="cat_t2">13.00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="ph12.3000.php" title="Phoenix 12/3000 возм. 3-ф подкл. " class="cat">Phoenix 12/3000 возм. 3-ф подкл. </a></td>
<td id="cat_t3">9,5-16,0</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">3000</td>
<td id="cat_t3">6000</td>
<td id="cat_t3">362x 258x 218</td>
<td id="cat_t3">18,00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="ph24.180.php" title="Phoenix 24/180 " class="cat">Phoenix 24/180 </a></td>
<td id="cat_t2">21,0-31,0</td>
<td id="cat_t2">230 В 50 Гц </td>
<td id="cat_t2">180</td>
<td id="cat_t2">200</td>
<td id="cat_t2">72x 132x 200</td>
<td id="cat_t2">2,70</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="ph24.350.php" title="Phoenix 24/350 " class="cat">Phoenix 24/350 </a></td>
<td id="cat_t3">21,0-31,0</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">350</td>
<td id="cat_t3">500</td>
<td id="cat_t3">72x 155x 237</td>
<td id="cat_t3">3.50</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="ph24.750.php" title="Phoenix 24/750 " class="cat">Phoenix 24/750 </a></td>
<td id="cat_t2">21,0-31,0</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">750</td>
<td id="cat_t2">1400</td>
<td id="cat_t2">72x 180x 295</td>
<td id="cat_t2">2.70</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phc24.1200.php" title="Phoenix C 24/1200 " class="cat">Phoenix C 24/1200 </a></td>
<td id="cat_t3">19,5-32,2</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">1200</td>
<td id="cat_t3">2200</td>
<td id="cat_t3">375x 214x 110</td>
<td id="cat_t3">10.00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phc24.1600.php" title="Phoenix C 24/1600 " class="cat">Phoenix C 24/1600 </a></td>
<td id="cat_t2">19,5-32,2</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">1600</td>
<td id="cat_t2">2300</td>
<td id="cat_t2">375x 214x 110</td>
<td id="cat_t2">10.00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phc24.2000.php" title="Phoenix C 24/2000" class="cat">Phoenix C 24/2000</a></td>
<td id="cat_t3">19,5-32,2</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">2000</td>
<td id="cat_t3">4000</td>
<td id="cat_t3">520x 255x 125  	</td>
<td id="cat_t3">13.00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phc24.3000.php" title="Phoenix C 24/3000 возм. 3-ф подкл. " class="cat">Phoenix C 24/3000 возм. 3-ф подкл. </a></td>
<td id="cat_t2">19,5-32,2</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">3000</td>
<td id="cat_t2">6000</td>
<td id="cat_t2">362x 258x 218	</td>
<td id="cat_t2">18.00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phc24.5000.php" title="Phoenix C 24/5000 возм. 3-ф подкл. " class="cat">Phoenix C 24/5000 возм. 3-ф подкл. </a></td>
<td id="cat_t3">19,5-33,0</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">5000</td>
<td id="cat_t3">9000</td>
<td id="cat_t3">444x 328x 240	</td>
<td id="cat_t3">30.00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="ph48.350.php" title="Phoenix 48/350 " class="cat">Phoenix 48/350 </a></td>
<td id="cat_t2">42,0-62,0</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">350</td>
<td id="cat_t2">500</td>
<td id="cat_t2">72x 155x 237</td>
<td id="cat_t2">3.50</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="ph48.750.php" title="Phoenix 48/750 " class="cat">Phoenix 48/750 </a></td>
<td id="cat_t3">42,0-62,0</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">750</td>
<td id="cat_t3">1400</td>
<td id="cat_t3">72x 180x 295  	</td>
<td id="cat_t3">2.70</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="ph48.3000.php" title="Phoenix 48/3000" class="cat">Phoenix 48/3000</a></td>
<td id="cat_t2">38,0-66,0</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">3000</td>
<td id="cat_t2">6000</td>
<td id="cat_t2">362x 258x 218	</td>
<td id="cat_t2">18.00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr></table></div>
	  </td>
	  </tr></table>
   </div>
<?php tail(); ?>