﻿<?php
include_once("../../Php/view.php");
head("Инверторы/зарядные устройства", $modes);
?>
<div id="text"><div>
	<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td id="t1">
			<?php out_left_colomn(); ?>
		</td>
		<td id="t2">
			<h1>Инверторы/зарядные устройства</h1><div id="cat_div">
<table cellpadding="0" cellspacing="1" widtd="100%">
<tr>
   <td id="cat_t1" rowspan="3">Модель</td>
   <td id="cat_t1" colspan="4">ИНВЕРТОР</td>
   <td id="cat_t1" colspan="4">ЗАРЯДНОЕ УСТРОЙСТВО</td>
   <td id="cat_t1" rowspan="3">Габа-<BR>риты<BR>HxWxD, мм</td>
   <td id="cat_t1" rowspan="3">Масса,<BR> кг</td>
   <td id="cat_t1" rowspan="3">Цена,<BR> EUR</td>
   <td id="cat_t1" rowspan="3">Цена,<BR> РУБ</td>
</tr>
<TR>
	<td ROWSPAN=2 id="cat_t1">Диап.<BR> входн.<BR> напр.<BR> пост.<BR> тока, В</td>
	<td ROWSPAN=2 id="cat_t1">Вых.<BR> напря-<BR>жение</td>
	<td ROWSPAN=2 id="cat_t1">Пост.<BR> вых.<BR> мощн. при<BR> 25°C,<BR> ВА</td>
	<td ROWSPAN=2 id="cat_t1">Пик.<BR> мощн.,<BR> Вт</td>
	<td ROWSPAN=2 id="cat_t1">Входн.&nbsp;<BR> напр.<BR> перем.<BR> тока</td>
	<td COLSPAN=2 id="cat_t1">Зарядное напряжение<BR> пост. ток, В</td>
	<td ROWSPAN=2 id="cat_t1">Ток<BR> заряд-<BR>ки сер-<BR>висной бата-<BR>реи, А</td>
</TR>
<tr>
	<td id="cat_t1">"погло-<BR>щение"</td>
	<td id="cat_t1">"напол-<BR>нение"</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phmc12.800.php" title="Phoenix Multi C 12/800/35-16 " class="cat">Phoenix Multi C 12/800/35-16 </a></td>
<td id="cat_t3">9,5-17</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">800</td>
<td id="cat_t3">1600</td>
<td id="cat_t3">187-265 В 45-55 Гц</td>
<td id="cat_t3">14,4</td>
<td id="cat_t3">13.8  	</td>
<td id="cat_t3">35,0</td>
<td id="cat_t3">375x 214x 110</td>
<td id="cat_t3">10,00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phmc12.1200.php" title="Phoenix MultiPlus C 12/1200/50-16 " class="cat">Phoenix MultiPlus C 12/1200/50-16 </a></td>
<td id="cat_t2">9,5-17</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">1200</td>
<td id="cat_t2">2400</td>
<td id="cat_t2">187-265 В 45-55 Гц</td>
<td id="cat_t2">14,4</td>
<td id="cat_t2">13,8</td>
<td id="cat_t2">50,0</td>
<td id="cat_t2">375x 214x 110</td>
<td id="cat_t2">10,00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phmc12.1600.php" title="Phoenix MultiPlus C 12/1600/70-16 " class="cat">Phoenix MultiPlus C 12/1600/70-16 </a></td>
<td id="cat_t3">9,5-17</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">1600</td>
<td id="cat_t3">3000</td>
<td id="cat_t3">187-265 В  187-265 В</td>
<td id="cat_t3">14.4</td>
<td id="cat_t3">13,8</td>
<td id="cat_t3">70,0</td>
<td id="cat_t3">375x 214x 110</td>
<td id="cat_t3">10,00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phec12.1600.php" title="Phoenix EasyPlus C 12/1600/70-16 " class="cat">Phoenix EasyPlus C 12/1600/70-16 </a></td>
<td id="cat_t2">9,5-17</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">1600</td>
<td id="cat_t2">3000</td>
<td id="cat_t2">187-265 В 45-55 Гц</td>
<td id="cat_t2">14,4</td>
<td id="cat_t2">13,8</td>
<td id="cat_t2">70,0</td>
<td id="cat_t2">510x 214x 110</td>
<td id="cat_t2">11,00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phmc12.2000.php" title="Phoenix MultiPlus C 12/2000/80-30 " class="cat">Phoenix MultiPlus C 12/2000/80-30 </a></td>
<td id="cat_t3">9,5-17</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">2000</td>
<td id="cat_t3">4000</td>
<td id="cat_t3">187-265 В 45-55 Гц</td>
<td id="cat_t3">14,4</td>
<td id="cat_t3">13,8</td>
<td id="cat_t3">80</td>
<td id="cat_t3">520x 255x 125</td>
<td id="cat_t3">13,00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phm12.3000.php" title="Phoenix MultiPlus 12/3000/120-16 возм. 3-ф подкл." class="cat">Phoenix MultiPlus 12/3000/120-16 возм. 3-ф подкл.</a></td>
<td id="cat_t2">9,5-17</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">3000</td>
<td id="cat_t2">6000</td>
<td id="cat_t2">187-265 В 45-55 Гц</td>
<td id="cat_t2">14,4</td>
<td id="cat_t2">13,8</td>
<td id="cat_t2">120,0</td>
<td id="cat_t2">362x 258x 218</td>
<td id="cat_t2">18,00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="q12.3000.php" title="Quattro 12/3000/120-50/30 возм. 3-ф подкл. " class="cat">Quattro 12/3000/120-50/30 возм. 3-ф подкл. </a></td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">3000</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">120,0</td>
<td id="cat_t3">362x 258x 218</td>
<td id="cat_t3">18.00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phm12.3000(2).php" title="Phoenix MultiPlus 12/3000/120-50 возм. 3-ф подкл." class="cat">Phoenix MultiPlus 12/3000/120-50 возм. 3-ф подкл.</a></td>
<td id="cat_t2">9,5-17</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">3000</td>
<td id="cat_t2">6000</td>
<td id="cat_t2">187-265 В 45-55 Гц</td>
<td id="cat_t2">14,4</td>
<td id="cat_t2">13,8</td>
<td id="cat_t2">120,0</td>
<td id="cat_t2">362x 258x 218</td>
<td id="cat_t2">18,00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="q12.5000.php" title="Quattro 12/5000/200-30/30 возм. 3-ф подкл." class="cat">Quattro 12/5000/200-30/30 возм. 3-ф подкл.</a></td>
<td id="cat_t3">9,5-17</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">5000</td>
<td id="cat_t3">8000</td>
<td id="cat_t3">187-265 В 45-55 Гц</td>
<td id="cat_t3">14,4</td>
<td id="cat_t3">13,8</td>
<td id="cat_t3">200,0</td>
<td id="cat_t3">444x 328x 240</td>
<td id="cat_t3">30,00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phmc24.800.php" title="Phoenix Multi C 24/800/16-16 " class="cat">Phoenix Multi C 24/800/16-16 </a></td>
<td id="cat_t2">19-33</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">1800</td>
<td id="cat_t2">1600</td>
<td id="cat_t2">187-265 В 45-55 Гц</td>
<td id="cat_t2">28.8</td>
<td id="cat_t2">27,6</td>
<td id="cat_t2">16,0</td>
<td id="cat_t2">375x 214x 110</td>
<td id="cat_t2">10,00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phmc24.1200.php" title="Phoenix Multi C 24/1200/25-16 " class="cat">Phoenix Multi C 24/1200/25-16 </a></td>
<td id="cat_t3">19-33</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">1200</td>
<td id="cat_t3">2400</td>
<td id="cat_t3">187-265 В 45-55 Гц</td>
<td id="cat_t3">28.8</td>
<td id="cat_t3">27,6</td>
<td id="cat_t3">25,0</td>
<td id="cat_t3">375x 214x 110</td>
<td id="cat_t3">10,00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phmc24.1600.php" title="Phoenix Multi C 24/1600/40-16" class="cat">Phoenix Multi C 24/1600/40-16</a></td>
<td id="cat_t2">19-33</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">1600</td>
<td id="cat_t2">3000</td>
<td id="cat_t2">187-265 В 45-55 Гц</td>
<td id="cat_t2">28.8</td>
<td id="cat_t2">27,6</td>
<td id="cat_t2">40,0</td>
<td id="cat_t2">375x 214x 110</td>
<td id="cat_t2">10,00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phmc24.2000.php" title="Phoenix Multi C 24/2000/50-30 " class="cat">Phoenix Multi C 24/2000/50-30 </a></td>
<td id="cat_t3">19-33</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">2000</td>
<td id="cat_t3">4000</td>
<td id="cat_t3">187-265 В 45-55 Гц</td>
<td id="cat_t3">28.8</td>
<td id="cat_t3">27,6</td>
<td id="cat_t3">50,0</td>
<td id="cat_t3">520x 255x 125</td>
<td id="cat_t3">13,00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phmc24.3000.php" title="Phoenix Multi C 24/3000/70-16" class="cat">Phoenix Multi C 24/3000/70-16</a></td>
<td id="cat_t2">19-33</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">3000</td>
<td id="cat_t2">6000</td>
<td id="cat_t2">187-265 В 45-55 Гц</td>
<td id="cat_t2">28.8</td>
<td id="cat_t2">27,6</td>
<td id="cat_t2">70,0</td>
<td id="cat_t2">362x 258x 218</td>
<td id="cat_t2">18,00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="q24.5000.php" title="Quattro 24/5000/120-30/30 возм. 3-ф подкл. " class="cat">Quattro 24/5000/120-30/30 возм. 3-ф подкл. </a></td>
<td id="cat_t3">19-33</td>
<td id="cat_t3">230 В 50 Гц </td>
<td id="cat_t3">5000</td>
<td id="cat_t3">1000</td>
<td id="cat_t3">187-265 В 45-65 Гц</td>
<td id="cat_t3">28.8</td>
<td id="cat_t3">27.6</td>
<td id="cat_t3">120.0</td>
<td id="cat_t3">444x 328x 240</td>
<td id="cat_t3">30.00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phm48.3000.php" title="Phoenix MultiPlus 48/3000/70-50 возм. 3-ф подкл." class="cat">Phoenix MultiPlus 48/3000/70-50 возм. 3-ф подкл.</a></td>
<td id="cat_t2">38-66</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">3000</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">40.0</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2">N/A</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="q24.3000.php" title="Quattro 24/3000/70-50/30 возм. 3-ф подкл. " class="cat">Quattro 24/3000/70-50/30 возм. 3-ф подкл. </a></td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">230 В 50 Гц </td>
<td id="cat_t3">3000</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">N/A</td>
<td id="cat_t3">70,0</td>
<td id="cat_t3">362x 258x 218</td>
<td id="cat_t3">18,00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="phm24.3000.php" title="Phoenix MultiPlus 24/3000/70-50 возм. 3-ф подкл. " class="cat">Phoenix MultiPlus 24/3000/70-50 возм. 3-ф подкл. </a></td>
<td id="cat_t2">19-33</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">3000</td>
<td id="cat_t2">6000</td>
<td id="cat_t2">187-265 В 45-55 Гц</td>
<td id="cat_t2">28.8</td>
<td id="cat_t2">27,6</td>
<td id="cat_t2">70.0</td>
<td id="cat_t2">362x 258x 218	</td>
<td id="cat_t2">18.00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phm48.3000(2).php" title="Phoenix MultiPlus 48/3000/35-16 возм. 3-ф подкл." class="cat">Phoenix MultiPlus 48/3000/35-16 возм. 3-ф подкл.</a></td>
<td id="cat_t3">38-66</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">3000</td>
<td id="cat_t3">6000</td>
<td id="cat_t3">187-265 В 45-55 Гц</td>
<td id="cat_t3">57.6</td>
<td id="cat_t3">55.2</td>
<td id="cat_t3">40.0</td>
<td id="cat_t3">362x 258x 218</td>
<td id="cat_t3">18.00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="q48.5000.php" title="Quattro 48/5000/70-50/30 возм. 3-ф подкл." class="cat">Quattro 48/5000/70-50/30 возм. 3-ф подкл.</a></td>
<td id="cat_t2">38-66</td>
<td id="cat_t2">230 В 50 Гц</td>
<td id="cat_t2">5000</td>
<td id="cat_t2">10000</td>
<td id="cat_t2">187-265 В 45-55 Гц</td>
<td id="cat_t2">57.6</td>
<td id="cat_t2">55.2</td>
<td id="cat_t2">70,0</td>
<td id="cat_t2">444x 328x 240</td>
<td id="cat_t2">30,00</td>
<td id="cat_t2" class="cat_price">--</td>
<td id="cat_t2" class="cat_price">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="phm48.3000(3).php" title="Phoenix MultiPlus 48/3000/35-50 возм. 3-ф подкл." class="cat">Phoenix MultiPlus 48/3000/35-50 возм. 3-ф подкл.</a></td>
<td id="cat_t3">38-66</td>
<td id="cat_t3">230 В 50 Гц</td>
<td id="cat_t3">3000</td>
<td id="cat_t3">6000</td>
<td id="cat_t3">187-265 В 45-55 Гц</td>
<td id="cat_t3">57.6</td>
<td id="cat_t3">55.2</td>
<td id="cat_t3">40.0</td>
<td id="cat_t3">362x 258x 218</td>
<td id="cat_t3">18.00</td>
<td id="cat_t3" class="cat_price">--</td>
<td id="cat_t3" class="cat_price">--</td>
</tr></table></div>

		</td>
	</tr>
	</table>
</div>
<?php tail($modes); ?>