﻿<?php
include_once("../../Php/view.php");
head("Зарядные устройства Phoenix", $modes);
?>
<div id="text"><div>
	<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
	<td id="t1">
		<?php out_left_colomn(); ?>
	</td>
	<td id="t2">
		<h1>Зарядные устройства Phoenix</h1><div id="cat_div">
<table cellpadding="0" cellspacing="1" width="100%">
<tr>
   <td id="cat_t1" rowspan="2">Модель</td>
   <td id="cat_t1" rowspan="2">Диапазон<BR> входного<BR> напряжения,<BR> перем. ток</td>
   <td id="cat_t1" colspan="3">Зарядное напряжение<BR> пост. ток, В</td>
   <td id="cat_t1" rowspan="2">Ток<BR> зарядки<BR> серв.<BR> батареи,<BR> А</td>
   <td id="cat_t1" rowspan="2">Ток<BR> зарядки<BR> старт.<BR> батареи,<BR> А</td>
   <td id="cat_t1" rowspan="2">Емкость<BR> батарей,<BR> А/час.</td>
   <td id="cat_t1" rowspan="2">Габариты<BR>HxWxD, мм</td>
   <td id="cat_t1" rowspan="2">Масса,<BR> кг</td>
   <td id="cat_t1" rowspan="2">Цена,<BR> EUR</td>  
   <td id="cat_t1" rowspan="2">Цена,<BR> РУБ</td>
</tr>
<tr>
   <td id="cat_t1">"погло-<BR>щение"</td>
   <td id="cat_t1">"напол-<BR>нение"</td>
   <td id="cat_t1">"хране-<BR>ние"</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="ph12.30.php" title="Phoenix 12/30" class="cat">Phoenix 12/30</a></td>
<td id="cat_t3">90-265 В 45-65 Гц</td>
<td id="cat_t3">14.4</td>
<td id="cat_t3">13.8</td>
<td id="cat_t3">13.2</td>
<td id="cat_t3">30.0</td>
<td id="cat_t3">4.0</td>
<td id="cat_t3">100-400</td>
<td id="cat_t3">350x 200x 108</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="ph12.50.php" title="Phoenix 12/50" class="cat">Phoenix 12/50</a></td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">14.4</td>
<td id="cat_t2">13.8</td>
<td id="cat_t2">13.2</td>
<td id="cat_t2">50.0</td>
<td id="cat_t2">4.0</td>
<td id="cat_t2">200-800</td>
<td id="cat_t2">350x 200x 108</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="ph24.16.php" title="Phoenix 24/16 " class="cat">Phoenix 24/16 </a></td>
<td id="cat_t3">90-265 В 45-65 Гц</td>
<td id="cat_t3">28.8</td>
<td id="cat_t3">27,6</td>
<td id="cat_t3">26,4</td>
<td id="cat_t3">16,0</td>
<td id="cat_t3">4.0</td>
<td id="cat_t3">100-200</td>
<td id="cat_t3">350x 200x 108</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="ph24.25.php" title="Phoenix 24/25" class="cat">Phoenix 24/25</a></td>
<td id="cat_t2">90-265 В 45-65 Гц</td>
<td id="cat_t2">28.8</td>
<td id="cat_t2">27,6</td>
<td id="cat_t2">26,4</td>
<td id="cat_t2">25,0</td>
<td id="cat_t2">4.0</td>
<td id="cat_t2">100-400</td>
<td id="cat_t2">350x 200x 108</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr></table></div>

	</td>
	</tr></table>
</div>

<?php tail($modes); ?>