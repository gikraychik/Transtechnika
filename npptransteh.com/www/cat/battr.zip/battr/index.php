﻿<?php
include_once("../../Php/view.php");
head("Аккумуляторные батареи", $modes);
?>
<div id="text"><div>
	<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
	<td id="t1">
		<?php out_left_colomn(); ?>
	</td>
	<td id="t2">
		<h1>АККУМУЛЯТОРНЫЕ БАТАРЕИ</h1>
<center><img src="/images/battr.jpg" alt=""></center><br><br>
<div id="cat_div">
<table cellpadding="0" cellspacing="1" width="100%">
<tr>
   <td id="cat_t1" TITLE="Модель">Модель</td>
<td id="cat_t1" TITLE="Габариты HeightxWidtdxDeptd, мм">Габариты<BR>HxWxD, мм</td>
<td id="cat_t1" TITLE="Масса, кг">Масса,<BR> кг</td>
<td id="cat_t1" TITLE="Цена, EUR">Цена,<BR> EUR</td>
<td id="cat_t1" TITLE="Цена, РУБ">Цена,<BR> РУБ</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Батарея 6В/225Ач AGM Deep Cycle</td>
<td id="cat_t2">247x 320x 176</td>
<td id="cat_t2">31.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Батарея 12В/7Ач AGM Deep Cycle</td>
<td id="cat_t3">100x 65x 151</td>
<td id="cat_t3">2.50</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Батарея 12В/12Ач AGM Deep Cycle</td>
<td id="cat_t2">247x 320x 176</td>
<td id="cat_t2">4.10</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Батарея 12В/20Ач AGM Deep Cycle</td>
<td id="cat_t3">167x 77x 181</td>
<td id="cat_t3">5.80</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Батарея 12В/35Ач AGM Deep Cycle</td>
<td id="cat_t2">180x 130x 195 </td>
<td id="cat_t2">12.50</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Батарея 12В/55Ач AGM Deep Cycle</td>
<td id="cat_t3">230x 138x 230 	</td>
<td id="cat_t3">20.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Батарея 12В/60Ач AGM Deep Cycle</td>
<td id="cat_t2">233x 168x 260 	</td>
<td id="cat_t2">24.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Батарея 12В/80Ач AGM Deep Cycle</td>
<td id="cat_t3">233x 168x 260</td>
<td id="cat_t3">27.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Батарея 12В/100Ач AGM Deep Cycle</td>
<td id="cat_t2">224x 171x 330</td>
<td id="cat_t2">32.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Батарея 12В/120Ач AGM Deep Cycle</td>
<td id="cat_t3">225x 176x 409</td>
<td id="cat_t3">38.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Батарея 12В/150Ач AGM Deep Cycle</td>
<td id="cat_t2">240x 172x 485</td>
<td id="cat_t2">47.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Батарея 12В/200Ач AGM Deep Cycle</td>
<td id="cat_t3">238x 238x 522</td>
<td id="cat_t3">65.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Батарея 12В/180Ач AGM для средств связи</td>
<td id="cat_t2">323x 125x 546</td>
<td id="cat_t2">60.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Батарея 12В/55Ач Gel Deep Cycle</td>
<td id="cat_t3">230x 138x 230</td>
<td id="cat_t3">20.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Батарея 12В/60Ач Gel Deep Cycle</td>
<td id="cat_t2">233x 168x 260</td>
<td id="cat_t2">24.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Батарея 12В/80Ач Gel Deep Cycle</td>
<td id="cat_t3">233x 168x 260</td>
<td id="cat_t3">26.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Батарея 12В/100Ач Gel Deep Cycle</td>
<td id="cat_t2">224x 171x 330</td>
<td id="cat_t2">33.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Батарея 12В/120Ач Gel Deep Cycle</td>
<td id="cat_t3">225x 176x 409</td>
<td id="cat_t3">38.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">Батарея 12В/150Ач Gel Deep Cycle</td>
<td id="cat_t2">240x 172x 485 	</td>
<td id="cat_t2">48.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">Батарея 12В/200Ач Gel Deep Cycle</td>
<td id="cat_t3">238x 238x 522</td>
<td id="cat_t3">66.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">2В/800Ач Gel</td>
<td id="cat_t2">710x 215x 193</td>
<td id="cat_t2">56.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">2В/1000Ач Gel</td>
<td id="cat_t3">710x 215x 235</td>
<td id="cat_t3">68.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">2В/1500Ач Gel</td>
<td id="cat_t2">855x 215x 277</td>
<td id="cat_t2">109.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">2В/2000Ач Gel</td>
<td id="cat_t3">815x 215x 400</td>
<td id="cat_t3">138.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">2В/3000Ач Gel</td>
<td id="cat_t2">815x 215x 580</td>
<td id="cat_t2">202.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">2В/600Ач (6 OPzS 600)</td>
<td id="cat_t3">206x 145x 666</td>
<td id="cat_t3">50.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">2В/800Ач (8 OPzS 800)</td>
<td id="cat_t2">210x 191x 666</td>
<td id="cat_t2">50.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">2В/1000Ач (10 OPzS 1000)</td>
<td id="cat_t3">666x 210x 233</td>
<td id="cat_t3">80.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">2В/1200Ач (12 OPzS 1200)</td>
<td id="cat_t2">666x 210x 233</td>
<td id="cat_t2">93.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">2В/1500Ач (12 OPzS 1500)</td>
<td id="cat_t3">821x 210x 275</td>
<td id="cat_t3">119.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;">2В/2000Ач (16 OPzS 2000)</td>
<td id="cat_t2">797x 212x 397</td>
<td id="cat_t2">160.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;">2В/3000Ач (24 OPzS 3000)</td>
<td id="cat_t3">797x 212x 576</td>
<td id="cat_t3">240.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr></table></div>

	</td>
	</tr></table>
</div>

<?php tail($modes); ?>