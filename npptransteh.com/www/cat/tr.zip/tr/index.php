﻿<?php
include_once("../../Php/view.php");
head("Разделительные трансформаторы", $modes);
?>
<div id="text"><div>
	<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
	<td id="t1">
		<?php out_left_colomn(); ?>
	</td>
	<td id="t2">
		<h1>Разделительные трансформаторы</h1><div id="cat_div">
<table cellpadding="0" cellspacing="1" width="100%">
<tr>	 
   <td id="cat_t1">Модель</td>
   <td id="cat_t1">Входное<BR> и выходн.<BR> напряж., В</td>
   <td id="cat_t1">Частота,<BR> Гц</td>
   <td id="cat_t1">Номи-<BR>нальный<BR> ток, А</td>
   <td id="cat_t1">Макс.<BR> ток, А</td>
   <td id="cat_t1">Пиковый<BR> ток.,<BR> А/мсек</td>
   <td id="cat_t1">Габариты<BR>HxWxD, мм</td>
   <td id="cat_t1">Масса,<BR> кг</td>
   <td id="cat_t1">Цена,<BR> EUR</td>
   <td id="cat_t1">Цена,<BR> РУБ</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="rt2000.php" title="Разделительный трансф. 2000 Вт " class="cat">Разделительный трансф. 2000 Вт </a></td>
<td id="cat_t3">115 / 230 </td>
<td id="cat_t3">50/60</td>
<td id="cat_t3">17 / 8,5</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
<td id="cat_t3">375x 214x 110</td>
<td id="cat_t3">10,00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="rt3600.php" title="Разделительный трансф. 3600 Вт " class="cat">Разделительный трансф. 3600 Вт </a></td>
<td id="cat_t2">115 / 230 </td>
<td id="cat_t2">50/60</td>
<td id="cat_t2">32 / 16</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
<td id="cat_t2">362x 258x 218</td>
<td id="cat_t2">23.00</td>
<td id="cat_t2">--</td>
<td id="cat_t2">--</td>
</tr><tr>
<td id="cat_t3" style="text-align:left;"><a href="rt7000.php" title="Разделительный трансф. 7000 Вт  " class="cat">Разделительный трансф. 7000 Вт  </a></td>
<td id="cat_t3">230</td>
<td id="cat_t3">50/60</td>
<td id="cat_t3">32</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
<td id="cat_t3">362x 258x 218</td>
<td id="cat_t3">24.00</td>
<td id="cat_t3">--</td>
<td id="cat_t3">--</td>
</tr><tr>
<td id="cat_t2" style="text-align:left;"><a href="givdi16.php" title="Гальванический изолятор VDI-16 " class="cat">Гальванический изолятор VDI-16 </a></td>
<td id="cat_t2">---</td>
<td id="cat_t2">---</td>
<td id="cat_t2">---</td>
<td id="cat_t2">16</td>
<td id="cat_t2">1600.00</td>
<td id="cat_t2">60x 120x 200</td>
<td id="cat_t2">1.00</td>
<td id="cat_t2">---</td>
<td id="cat_t2">---</td>
</tr></table></div>

	</td>
	</tr></table>
</div>

<?php tail($modes); ?>